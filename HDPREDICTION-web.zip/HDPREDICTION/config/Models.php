<?php
include "CRUD.php";
include "functions.php";

function user() {
	$crud = new CRUD;
	$crud->table = "user";
	return $crud;
}

function medicine() {
	$crud = new CRUD;
	$crud->table = "medicine";
	return $crud;
}

function appointment() {
	$crud = new CRUD;
	$crud->table = "appointment";
	return $crud;
}

function knn() {
	$crud = new CRUD;
	$crud->table = "knn";
	return $crud;
}

?>
