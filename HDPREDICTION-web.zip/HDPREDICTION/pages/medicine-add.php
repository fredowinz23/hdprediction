<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";
?>

<br>

<center>
<div class="card">
  <div class="card-header">
    <b>New Medicine Form</b>
  </div>
  <div class="card-body">
    <form class="" action="process.php?action=medicine-add" enctype="multipart/form-data" method="post">
      <div class="row">
        <div class="col">
          <b>Name</b>
          <input type="text" name="name" class="form-control" required>
          <br>
          <b>Image</b>
          <input name="image" accept="image/*" type='file' class="form-control" id="imgInp" />
          <i>Preview:</i> <br>
          <img id="blah" src="../templates/image-preview.png" alt="your image" style="width:50%" />
          <br>  <br>
        </div>
        <div class="col">

            <b>Uses</b>
            <textarea name="uses" rows="5" class="form-control"></textarea>
            <br>  <br>
            <b>Side Effect</b>
            <textarea name="sideEffect" rows="5" class="form-control"></textarea>
            <br>  <br>
            <b>Precaution</b>
            <textarea name="precaution" rows="5" class="form-control"></textarea>
        </div>
      </div>

      <button type="submit" class="btn btn-primary mt-3">Create</button>
    </form>
  </div>
</div>
</center>

<script type="text/javascript">
imgInp.onchange = evt => {
const [file] = imgInp.files
if (file) {
  blah.src = URL.createObjectURL(file)
}
}
</script>
<?php include $ROOT_DIR . "templates/footer.php"; ?>
