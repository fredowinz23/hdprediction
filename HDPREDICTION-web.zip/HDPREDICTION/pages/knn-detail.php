<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$Id = get_query_string("Id","");
$knn = knn()->get("Id=$Id");

$knn_list = knn()->list();

?>


<table class="table">
  <tr>
    <th>USER</th>
    <th>AGE</th>
    <th>SEX</th>
    <th>CP</th>
    <th>TRESTBPS</th>
    <th>CHOL</th>
    <th>FBS</th>
    <th>RESTECG</th>
    <th>THALACH</th>
    <th>EXANG</th>
    <th>OLDPEAK</th>
    <th>SLOPE</th>
    <th>CA</th>
    <th>THAL</th>
  </tr>

    <tr>
      <td><?=$knn->userId;?></td>
      <td><?=$knn->age;?></td>
      <td><?=$knn->sex;?></td>
      <td><?=$knn->cp;?></td>
      <td><?=$knn->trestbps;?></td>
      <td><?=$knn->chol;?></td>
      <td><?=$knn->fbs;?></td>
      <td><?=$knn->restecg;?></td>
      <td><?=$knn->thalach;?></td>
      <td><?=$knn->exang;?></td>
      <td><?=$knn->oldpeak;?></td>
      <td><?=$knn->slope;?></td>
      <td><?=$knn->ca;?></td>
      <td><?=$knn->thal;?></td>

    </tr>

</table>

<table class="table">
  <tr>
    <th>#</th>
    <th>USER</th>
    <th>AGE</th>
    <th>SEX</th>
    <th>CP</th>
    <th>TRESTBPS</th>
    <th>CHOL</th>
    <th>FBS</th>
    <th>RESTECG</th>
    <th>THALACH</th>
    <th>EXANG</th>
    <th>OLDPEAK</th>
    <th>SLOPE</th>
    <th>CA</th>
    <th>THAL</th>
    <th>RESULT</th>
    <th>DISTANCE</th>
  </tr>

  <?php
  $count = 0;
  $k = 0;
  $totalDistance = 0;
  $result1 = 0;
   foreach ($knn_list as $row):
     if ($row->Id==$knn->Id) {
       break;
     }
     $count += 1;
     $age = pow($knn->age-$row->age,2);
     $sex = pow($knn->sex-$row->sex,2);
     $cp = pow($knn->cp-$row->cp,2);
     $trestbps = pow($knn->trestbps-$row->trestbps,2);
     $chol = pow($knn->chol-$row->chol,2);
     $fbs = pow($knn->fbs-$row->fbs,2);
     $restecg = pow($knn->restecg-$row->restecg,2);
     $thalach = pow($knn->thalach-$row->thalach,2);
     $exang = pow($knn->exang-$row->exang,2);
     $oldpeak = pow($knn->oldpeak-$row->oldpeak,2);
     $slope = pow($knn->slope-$row->slope,2);
     $ca = pow($knn->ca-$row->ca,2);
     $thal = pow($knn->thal-$row->thal,2);
     $total = $age + $sex + $cp + $trestbps + $chol + $fbs + $restecg + $thalach + $exang + $oldpeak + $slope + $ca + $thal;
     $distance  = decimal_2(sqrt($total));
     if ($distance>=70) {
       $result = 1;
       $result1 += 100;
     }
     else{
       $result = 0;
     }

     // First Five
     // if ($count<=5) {
     //   if ($result==1) {
     //     $k += 20;
     //   }
     // }

     $totalDistance += $distance;

     ?>

    <tr>
      <td><?=$count;?></td>
      <td><?=$row->userId;?></td>
      <td><?=$age;?></td>
      <td><?=$sex;?></td>
      <td><?=$cp;?></td>
      <td><?=$trestbps;?></td>
      <td><?=$chol;?></td>
      <td><?=$fbs;?></td>
      <td><?=$restecg;?></td>
      <td><?=$thalach;?></td>
      <td><?=$exang;?></td>
      <td><?=$oldpeak;?></td>
      <td><?=$slope;?></td>
      <td><?=$ca;?></td>
      <td><?=$thal;?></td>
      <td><?=$result;?></td>
      <td><?=$distance;?></td>
    </tr>
  <?php endforeach; ?>

</table>
<hr>
<h1>K: <?=decimal_2($result1/($count))?>%</h1>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
