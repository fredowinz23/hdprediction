<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$Id = $_GET["Id"];
$user = user()->get("Id=$Id");

?>

<style media="screen">
  .clickable{
    cursor: pointer;
  }
    .clickable:hover{
      background: gray;
    }
</style>

<section style="background-color: #eee;">

    <div class="row">
      <div class="col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
            <h5 class="my-3"><?=$user->firstName;?> <?=$user->lastName;?></h5>
            <p class="text-muted mb-1"><?=$user->role;?></p>
            <p class="text-muted mb-1"><?=$user->status;?></p>
            <br><br>
            <div class="d-flex justify-content-center mb-2">
              <?php if ($user->status=="Disabled"): ?>
                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#enableModal">Activate</button>
                <?php else: ?>
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#disableModal">Disable</button>
              <?php endif; ?>

            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card mb-4">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Full Name</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?=$user->firstName;?> <?=$user->lastName;?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Email</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?=$user->email;?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Mobile</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?=$user->phone;?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<div class="modal fade" id="disableModal" tabindex="-1" aria-labelledby="assignDaysModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="assignDaysModalLabel">Confirmation Message!</h5>
        <a type="button" class="btn-close" data-dismiss="modal" aria-label="Close">X</a>
      </div>

        <div class="modal-body">
          <input type="hidden" name="userId" id="<?=$Id?>">
          Are you sure you want to disable this account?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <a href="process.php?action=change-user-status&status=Disabled&Id=<?=$Id?>" class="btn btn-primary">Confirm</a>
        </div>
    </div>
  </div>
</div>


<div class="modal fade" id="enableModal" tabindex="-1" aria-labelledby="assignDaysModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="assignDaysModalLabel">Confirmation Message!</h5>
        <a type="button" class="btn-close" data-dismiss="modal" aria-label="Close">X</a>
      </div>

        <div class="modal-body">
          <input type="hidden" name="userId" id="<?=$Id?>">
          Are you sure you want to activate this account?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <a href="process.php?action=change-user-status&status=Active&Id=<?=$Id?>" class="btn btn-primary">Confirm</a>
        </div>
    </div>
  </div>
</div>

<div class="modal fade" id="reAssignModal" tabindex="-1" aria-labelledby="assignDaysModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="assignDaysModalLabel">Select New Department</h5>
        <a type="button" class="btn-close" data-dismiss="modal" aria-label="Close">X</a>
      </div>

        <div class="modal-body">
          <div class="row">
            <?php foreach ($department_list as $row): ?>
              <div class="col-4">
                <div class="card clickable" onclick="location.href='process.php?action=change-department&newDepartment=<?=$row->Id?>&userId=<?=$Id?>'">
                  <div class="card-body">
                    <b><?=$row->name;?></b>
                  </div>
                </div>

              </div>
            <?php endforeach; ?>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
