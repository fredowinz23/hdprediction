<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$medicine_list = medicine()->list();

?>
<center>
<h2>Medicines</h2>
</center>

<a href="medicine-add.php" class="btn btn-primary">Add New Medicine +</a>



<div class="row mt-3 mb-3">
  <?php foreach ($medicine_list as $row):
     ?>
    <div class="col-lg-3 mt-2">
        <div class="card card-box" onclick="location.href='medicine-detail.php?Id=<?=$row->Id;?>'">
          <div class="card-body">
            <h3><?=$row->name;?></h3>
          </div>
        </div>
    </div>
<?php endforeach;?>
</div>


<?php include $ROOT_DIR . "templates/footer.php"; ?>
