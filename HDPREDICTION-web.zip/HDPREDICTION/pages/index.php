<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";
?>

<br>

<h2>Welcome to Mobile Heart Disease Prediction System </h2>



<?php include $ROOT_DIR . "templates/footer.php"; ?>
