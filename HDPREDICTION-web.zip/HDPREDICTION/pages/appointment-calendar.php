<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";


$user = user()->get("username='$username'");

$appointment_list = appointment()->list("cardiologistId=$user->Id");
?>

<link href='<?=$ROOT_DIR;?>fullcalendar/lib/main.css' rel='stylesheet' />
<script src='<?=$ROOT_DIR;?>fullcalendar/lib/main.js'></script>
<script>

  document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
      initialDate: '<?=date("Y-m-d")?>',
      validRange: {
        start: '<?=date("Y-m-d")?>'
      },
      navLinks: true, // can click day/week names to navigate views
      selectable: true,
      selectMirror: false,
      select: function(arg) {
        location.href='appointment-list.php?appointmentDate=' + arg.startStr;
        calendar.unselect()
      },
      editable: false,
      dayMaxEvents: 5, // allow "more" link when too many events
      events: [
        <?php foreach ($appointment_list as $row):
              $patient = user()->get("Id=$row->patientId");
              ?>
                {
                  title: 'Patient: <?=$patient->firstName;?> <?=$patient->lastName;?>',
                  start: '<?=$row->appointmentDate?>',
                  end: '<?=$row->appointmentDate?>',
                },
        <?php  endforeach; ?>
      ]
    });
    calendar.render();
  });

</script>
<style>

  #calendar {
    max-width: 1100px;
    margin: 0 auto;
  }

</style>
  <div id='calendar'></div>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
