<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$Id = $_GET["Id"];
$user = user()->get("Id=$Id");
?>

<form action="process.php?action=user-edit" enctype="multipart/form-data" method="post">
<div class="card">
  <div class="card-header">
    <b>User Form</b>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-6">
        <b>Username</b> <span style="color:red;"><?=$error;?></span>
        <input type="text" name="username" value="<?=$user->username;?>" class="form-control" disabled>
        <input type="hidden" name="Id" value="<?=$Id;?>">
      </div>
      <div class="col-lg-6">
        <b>Temporary Password</b>
        <?php if ($user->status=="Inactive"): ?>
          <input type="text" class="form-control" value="TEMP: <?=$temp_password;?>" disabled>
          <?php else: ?>
          <input type="text" class="form-control" value="Not Shown for Security" disabled>
        <?php endif; ?>
      </div>
      <div class="col-lg-6">
        <b>First Name</b>
        <input type="text" name="firstName" value="<?=$user->firstName;?>" class="form-control" required>
      </div>

      <div class="col-lg-6">
        <b>Last Name</b>
        <input type="text" name="lastName" value="<?=$user->lastName;?>" class="form-control" required>
      </div>
      <div class="col-lg-4">
        <b>Phone Number</b>
        <input type="number" name="phone" value="<?=$user->phone;?>"class="form-control" required>
      </div>
      <div class="col-lg-4">
        <b>Email</b>
        <input type="text" name="email" class="form-control" value="<?=$user->email;?>" required>
      </div>
    </div>
  </div>
  <div class="card-footer">
    <button type="submit" class="btn btn-primary">Add</button>
  </div>
</div>

</form>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
