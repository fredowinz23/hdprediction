<?php
session_start();
require_once '../config/database.php';
require_once '../config/Models.php';

$action = $_GET['action'];

switch ($action) {

	case 'user-add' :
		user_add();
		break;

	case 'medicine-add' :
		medicine_add();
		break;

	case 'change-appointment-status' :
		change_appointment_status();
		break;

// ================================================

	case 'department-add' :
		department_add();
		break;

	case 'create-nurse-schedule' :
		create_nurse_schedule();
		break;

	case 'leave-type-add' :
		leave_type_add();
		break;

	case 'attendance-add' :
		attendance_add();
		break;

	case 'attendance-delete' :
		attendance_delete();
		break;

	case 'remove-schedule' :
		remove_schedule();
		break;

	case 'change-leave-request-status' :
		change_leave_request_status();
		break;

	case 'assign-day-off' :
		assign_day_off();
		break;

	case 'auto-assign-schedule' :
		auto_assign_schedule();
		break;

	case 'change-user-status' :
		change_user_status();
		break;

	case 'change-department' :
		change_department();
		break;

	default :
}

function user_add(){

	$username = $_POST["username"];
	$checkUser = user()->count("username='$username'");

	if ($checkUser>=1) {
		header('Location: user-add.php?role='.$_POST["role"].'&error=Username Already Exists');
	}
	else{
			$model = user();
			$model->obj["username"] = $_POST["username"];
			$model->obj["firstName"] = $_POST["firstName"];
			$model->obj["role"] = $_POST["role"];
			$model->obj["phone"] = $_POST["phone"];
			$model->obj["email"] = $_POST["email"];
			$model->obj["lastName"] = $_POST["lastName"];
			$model->obj["password"] = $_POST["password"];
			$model->obj["dateAdded"] = "NOW()";
			$model->create();
			header('Location: accounts.php?role=' . $_POST["role"]);
	}
}

function medicine_add(){
	#Process to save to the database
	$image_name = uploadFile($_FILES["image"]);
	$model = medicine();
	$model->obj["name"] = $_POST["name"];
	$model->obj["image"] = $image_name;
	$model->obj["uses"] = $_POST["uses"];
	$model->obj["sideEffect"] = $_POST["sideEffect"];
	$model->obj["precaution"] = $_POST["precaution"];
	$model->obj["addedById"] = $_SESSION["user_session"]["Id"];
	$model->obj["dateAdded"] = "NOW()";
	$model->create();

	header('Location: medicines.php');
}


function change_appointment_status(){
	#Process to save to the database
	$Id = $_GET["Id"];
	$model = appointment();
	$model->obj["status"] = $_GET["status"];
	$model->update("Id=$Id");

	header('Location: appointment-detail.php?Id=' . $Id);
}


// ===================================================

function assign_day_off(){
	$userId = $_POST["userId"];
	$model = user();
	$model->obj["off"] = implode(', ', $_POST['daysArray']);
	$model->update("Id=$userId");

	header('Location: department-members.php?departmentId=' .$_POST["departmentId"]);
}

function change_user_status(){
	#Process to save to the database
	$Id = $_GET["Id"];
	$model = user();
	$model->obj["status"] = $_GET["status"];
	$model->update("Id=$Id");

	header('Location: user-detail.php?Id=' . $Id);
}

function change_department(){
	#Process to save to the database
	$userId = $_GET["userId"];
	$model = user();
	$model->obj["departmentId"] = $_GET["newDepartment"];
	$model->update("Id=$userId");

	header('Location: user-detail.php?Id=' . $userId);
}

function department_add(){
	#Process to save to the database
	$model = department();
	$model->obj["name"] = $_POST["name"];
	$model->obj["description"] = $_POST["description"];
	$model->create();

	header('Location: department.php');
}

function attendance_add(){
	#Process to save to the database
	$model = attendance();
	$model->obj["nurseId"] = $_GET["nurseId"];
	$model->obj["date"] = $_GET["date"];
	$model->obj["status"] = $_GET["status"];
	$model->create();

	header('Location: attendance-list-form.php?date=' . $_GET["date"]);
}

function attendance_delete(){
	#Process to save to the database
	$Id = $_GET["Id"];
	$model = attendance();
	$model->delete("Id=$Id");

	header('Location: attendance-list-form.php?date=' . $_GET["date"]);
}

function change_leave_request_status(){
	#Process to save to the database
	$Id = $_GET["Id"];
	$model = leave_request();
	$model->obj["status"] = $_GET["status"];
	$model->update("Id=$Id");

	header('Location: leave-request-detail.php?Id=' . $Id);
}

function leave_type_add(){
	#Process to save to the database
	$model = leave_type();
	$model->obj["name"] = $_POST["name"];
	$model->obj["description"] = $_POST["description"];
	$model->create();

	header('Location: leave-types.php');
}

function create_nurse_schedule(){

	$startDate = $_POST["start"];
	while($startDate !=  $_POST["end"]) {
			$model = schedule();
			$model->obj["nurseId"] = $_POST["nurseId"];
			$model->obj["startDate"] = $startDate;
			$model->obj["shift"] = $_POST["shift"];
			$model->obj["dateAdded"] = "NOW()";
			$model->create();
		$startDate = date('Y-m-d', strtotime($startDate . ' + 1 day'));
	}
	header('Location: nurse-calendar.php?nurseId=' . $_POST['nurseId']);
}

function auto_assign_schedule(){


	$departmentId = $_GET["departmentId"];
	$nurse_list = user()->list("role='Nurse' and departmentId=$departmentId");
	$startDate = date('Y-m-') . "1";
	$endDate = date('Y-m-') . "31";

	while($startDate !=  $endDate) {

			$count = 0;
			foreach ($nurse_list as $row) {
				$count += 1;
				$model = schedule();
				$model->obj["nurseId"] = $row->Id;
				$model->obj["startDate"] = $startDate;
				if ($count%6==0 || $count%6==3) {
					$model->obj["shift"] = "Morning";
				}
				if ($count%6==1 || $count%6==4) {
					$model->obj["shift"] = "Afternoon";
				}
				if ($count%6==2 || $count%6==5) {
					$model->obj["shift"] = "Night";
				}
				$model->obj["dateAdded"] = "NOW()";

				$dayofweek = date('l', strtotime($startDate));
				if(strpos($row->off, $dayofweek) !== false){

				} else{
					$checkScheduleExist = schedule()->count("nurseId=$row->Id and startDate='$startDate'");

					if ($checkScheduleExist==0) {
						$model->create();
					}
				}
			}

		$startDate = date('Y-m-d', strtotime($startDate . ' + 1 day'));
	}

	header('Location: schedule-calendar.php');

}

function remove_schedule(){

	$nurseId = $_GET["nurseId"];
	$startDate = $_GET["start"];
	while($startDate !=  $_GET["end"]) {
		$model = schedule();
		$model->delete("nurseId=$nurseId and startDate='$startDate'");
		$startDate = date('Y-m-d', strtotime($startDate . ' + 1 day'));
	}

	header('Location: nurse-calendar.php?nurseId=' . $_GET['nurseId']);
}
