<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$Id = $_GET["Id"];
$med = medicine()->get("Id=$Id");

?>

<style media="screen">
  .clickable{
    cursor: pointer;
  }
    .clickable:hover{
      background: gray;
    }
</style>

<section style="background-color: #eee;">

    <div class="row">
      <div class="col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
            <h3 class="my-3"><?=$med->name;?></h3>
            <img src="../media/<?=$med->image;?>" alt="" style="width:100%">
          </div>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card mb-4">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Uses</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?=$med->uses;?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Side Effects</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?=$med->sideEffect;?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Precaution</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?=$med->precaution;?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<div class="modal fade" id="disableModal" tabindex="-1" aria-labelledby="assignDaysModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="assignDaysModalLabel">Confirmation Message!</h5>
        <a type="button" class="btn-close" data-dismiss="modal" aria-label="Close">X</a>
      </div>

        <div class="modal-body">
          <input type="hidden" name="userId" id="<?=$Id?>">
          Are you sure you want to disable this account?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <a href="process.php?action=change-user-status&status=Disabled&Id=<?=$Id?>" class="btn btn-primary">Confirm</a>
        </div>
    </div>
  </div>
</div>


<div class="modal fade" id="enableModal" tabindex="-1" aria-labelledby="assignDaysModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="assignDaysModalLabel">Confirmation Message!</h5>
        <a type="button" class="btn-close" data-dismiss="modal" aria-label="Close">X</a>
      </div>

        <div class="modal-body">
          <input type="hidden" name="userId" id="<?=$Id?>">
          Are you sure you want to activate this account?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <a href="process.php?action=change-user-status&status=Active&Id=<?=$Id?>" class="btn btn-primary">Confirm</a>
        </div>
    </div>
  </div>
</div>

<div class="modal fade" id="reAssignModal" tabindex="-1" aria-labelledby="assignDaysModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="assignDaysModalLabel">Select New Department</h5>
        <a type="button" class="btn-close" data-dismiss="modal" aria-label="Close">X</a>
      </div>

        <div class="modal-body">
          <div class="row">
            <?php foreach ($department_list as $row): ?>
              <div class="col-4">
                <div class="card clickable" onclick="location.href='process.php?action=change-department&newDepartment=<?=$row->Id?>&userId=<?=$Id?>'">
                  <div class="card-body">
                    <b><?=$row->name;?></b>
                  </div>
                </div>

              </div>
            <?php endforeach; ?>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
