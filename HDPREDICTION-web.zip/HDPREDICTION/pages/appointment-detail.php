<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";
  $Id = $_GET["Id"];
  $app = appointment()->get("Id=$Id");
  $patient = user()->get("Id=$app->patientId");

?>

<div class="card">
  <div class="card-body">
    <h3>Appointment Detail</h3>
    <hr>

        <b>Appointment Date:</b>
        <i><?=$app->appointmentDate;?></i> <br>
            <b>Patient:</b>
          <i><?=$patient->firstName;?> <?=$patient->lastName;?></i> <br>
              <b>Status:</b>
            <i><?=$app->status;?></i> <br>
                <b>Note:</b>
              <i><?=$app->note;?></i>

<hr>
<?php if ($app->status=="Pending"): ?>
  <a href="process.php?action=change-appointment-status&status=Approved&Id=<?=$Id?>" class="btn btn-primary">Approve</a>
    <a href="process.php?action=change-appointment-status&status=Denied&Id=<?=$Id?>" class="btn btn-danger">Deny</a>
<?php elseif ($app->status=="Approved"): ?>
  <a href="process.php?action=change-appointment-status&status=Done&Id=<?=$Id?>" class="btn btn-primary">Done</a>
  <?php else: ?>
    <a href="process.php?action=change-appointment-status&status=Pending&Id=<?=$Id?>" class="btn btn-warning">Change Status</a>
<?php endif; ?>

  </div>
</div>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
