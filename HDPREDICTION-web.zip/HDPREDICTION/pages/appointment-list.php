<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$appointmentDate = get_query_string("appointmentDate", "");

$sessionId = $_SESSION["user_session"]["Id"];

$appointment_list = appointment()->list("appointmentDate='$appointmentDate' and cardiologistId=$sessionId");

?>

<br>

<table class="table">
  <tr>
    <th>#</th>
    <th>Date</th>
    <th>Patient</th>
    <th>Cardiologist</th>
    <th>Status</th>
    <th>Note</th>
    <th>Date Added</th>
    <th width="100">Action</th>
  </tr>

  <?php
  $count = 0;
   foreach ($appointment_list as $row):
     $patient = user()->get("Id=$row->patientId");
     $cardiologist = user()->get("Id=$row->cardiologistId");
     $count += 1;
     ?>
    <tr>
      <td><?=$count;?></td>
      <td><?=$row->appointmentDate;?></td>
      <td><?=$patient->firstName;?> <?=$patient->lastName;?></td>
      <td><?=$cardiologist->firstName;?> <?=$cardiologist->lastName;?></td>
      <td><?=$row->status;?></td>
      <td><?=$row->note;?></td>
      <td><?=$row->dateAdded;?></td>
      <td><a href="appointment-detail.php?Id=<?=$row->Id;?>" class="btn btn-primary btn-sm">View</a></td>
    </tr>
  <?php endforeach; ?>
</table>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
