<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$role = get_query_string("role", "Admin");
$user_list = user()->list("role='$role'");

?>

<?php if ($role!="Patient"): ?>
    <div class="row">
      <div class="col-12 text-left">
        <a href="user-add.php?role=<?=$role;?>" class="btn btn-primary mt-3">Add New <?=$role;?></a>
      </div>
    </div>
  <br>
<?php endif; ?>




<table class="table">
  <tr>
    <th>#</th>
    <th>Role</th>
    <th>Username</th>
    <th>Password</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Status</th>
    <th>Date Added</th>
    <th width="100">Action</th>
  </tr>

  <?php
  $count = 0;
   foreach ($user_list as $row):
     $count += 1;
     ?>
    <tr>
      <td><?=$count;?></td>
      <td><?=$row->role;?></td>
      <td><?=$row->username;?></td>
      <?php if ($row->status=="Inactive" && $role!="Household"): ?>
      <td>TEMP: <span style="color:red;font-style:italic;"><?=$row->password;?></span></td>
        <?php else: ?>
        <td><span style="color:gray;font-style:italic;">Not Shown for Security</span></td>
      <?php endif; ?>
      <td><?=$row->firstName;?></td>
      <td><?=$row->lastName;?></td>
      <td><?=$row->status;?></td>
      <td><?=$row->dateAdded;?></td>
      <td><a href="user-detail.php?Id=<?=$row->Id;?>" class="btn btn-primary btn-sm">View</a></td>

    </tr>
  <?php endforeach; ?>

</table>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
