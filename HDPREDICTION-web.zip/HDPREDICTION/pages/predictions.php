<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$knn_list = knn()->list();

?>

<table class="table">
  <tr>
    <th>#</th>
    <th>USER</th>
    <th>AGE</th>
    <th>SEX</th>
    <th>CP</th>
    <th>TRESTBPS</th>
    <th>CHOL</th>
    <th>FBS</th>
    <th>RESTECG</th>
    <th>THALACH</th>
    <th>EXANG</th>
    <th>OLDPEAK</th>
    <th>SLOPE</th>
    <th>CA</th>
    <th>THAL</th>
    <th width="100">Action</th>
  </tr>

  <?php
  $count = 0;
   foreach ($knn_list as $row):
     $count += 1;
     ?>
    <tr>
      <td><?=$count;?></td>
      <td><?=$row->userId;?></td>
      <td><?=$row->age;?></td>
      <td><?=$row->sex;?></td>
      <td><?=$row->cp;?></td>
      <td><?=$row->trestbps;?></td>
      <td><?=$row->chol;?></td>
      <td><?=$row->fbs;?></td>
      <td><?=$row->restecg;?></td>
      <td><?=$row->thalach;?></td>
      <td><?=$row->exang;?></td>
      <td><?=$row->oldpeak;?></td>
      <td><?=$row->slope;?></td>
      <td><?=$row->ca;?></td>
      <td><?=$row->thal;?></td>
      <td><a href="knn-detail.php?Id=<?=$row->Id;?>" class="btn btn-primary btn-sm">View</a></td>

    </tr>
  <?php endforeach; ?>

</table>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
