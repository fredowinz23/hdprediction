<br><br><br>
</div>
</div>
</div>
<!-- /.col-lg-9-->


          </div>
        </div>
      </div>
    </div>
    <!--
    *** FOOTER ***
    _________________________________________________________
    -->

    <!--
    *** COPYRIGHT ***
    _________________________________________________________
    -->

    <!-- *** COPYRIGHT END ***-->
    <!-- JavaScript files-->
    <script src="<?=$ROOT_DIR;?>templates/vendor/jquery/jquery.min.js"></script>
    <script src="<?=$ROOT_DIR;?>templates/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?=$ROOT_DIR;?>templates/vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="<?=$ROOT_DIR;?>templates/vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="<?=$ROOT_DIR;?>templates/vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.js"></script>
    <script src="<?=$ROOT_DIR;?>templates/js/front.js"></script>
  </body>
</html>
