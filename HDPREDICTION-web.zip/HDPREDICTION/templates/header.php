<?php
session_start();
require_once '../config/database.php';
require_once '../config/Models.php';
$ROOT_DIR = "../";

if (!isset($_SESSION["user_session"]["username"])) {
  header('Location: ../auth/login.php');
}

$username = $_SESSION["user_session"]["username"];
$loggedInUser = user()->get("username='$username'");
?>

<style media="screen">
  .li-link{
    cursor: pointer;
  }
  .li-link:hover{
    background: #f0f2f0;
  }
  .li-header{
    font-weight: bold;
  }
</style>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mobile Heart Disease Prediction
</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700">
    <!-- owl carousel-->
    <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/vendor/owl.carousel/assets/owl.carousel.css">
    <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/vendor/owl.carousel/assets/owl.theme.default.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/css/style.custom.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/css/custom.css">
    <!-- Favicon-->
    <!-- <link rel="shortcut icon" href="<?=$ROOT_DIR;?>templates/favicon.png"> -->
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- navbar-->
    <header class="header mb-5">
      <!--
      *** TOPBAR ***
      _________________________________________________________
      -->
      <div id="top">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 offer mb-3 mb-lg-0"></div>
            <div class="col-lg-6 text-center text-lg-right">
              <ul class="menu list-inline mb-0">
                <?php if (isset($_SESSION["user_session"]["username"])): ?>
                  <li class="list-inline-item"><a href="#"><?=$_SESSION["user_session"]["firstName"]?> <?=$_SESSION["user_session"]["lastName"]?> (<?=$_SESSION["user_session"]["role"]?>)</li>
                  <li class="list-inline-item"> &nbsp;&nbsp; <a href="../auth/process.php?action=user-logout"><b>LOGOUT</b></a></li>
                  <?php else: ?>
                  <li class="list-inline-item"><a href="#" data-toggle="modal" data-target="#login-modal">Login</a></li>
                  <li class="list-inline-item"><a href="../auth/register.php">Register</a></li>
                <?php endif; ?>
              </ul>
            </div>
          </div>
        </div>
        <div id="login-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true" class="modal fade">
          <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">login</h5>
                <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
              </div>
              <div class="modal-body">
                <form action="../auth/process.php?action=user-login" method="post">
                  <div class="form-group">
                    <input id="email-modal" name="username" type="text" placeholder="username" class="form-control">
                  </div>
                  <div class="form-group">
                    <input id="password-modal" name="password" type="password" placeholder="password" class="form-control">
                  </div>
                  <p class="text-center">
                    <button class="btn btn-primary"><i class="fa fa-sign-in"></i> Log in</button>
                  </p>
                </form>
                <p class="text-center text-muted">Not registered yet?</p>
                <p class="text-center text-muted"><a href="../auth/register.php"><strong>Register now</strong></a>! It is easy and done in 1 minute and gives you access to special discounts and much more!</p>
              </div>
            </div>
          </div>
        </div>
        <!-- *** TOP BAR END ***-->


      </div>
      <nav class="navbar navbar-expand-lg">
        <div class="container"><a href="../pages" class="navbar-brand home"><img src="<?=$ROOT_DIR;?>templates/img/logo.png" alt="Obaju logo" class="d-none d-md-inline-block"><img src="img/logo-small.png" alt="Obaju logo" class="d-inline-block d-md-none"><span class="sr-only">Obaju - go to homepage</span></a>
          <div class="navbar-buttons">
            <button type="button" data-toggle="collapse" data-target="#navigation" class="btn btn-outline-secondary navbar-toggler"><span class="sr-only">Toggle navigation</span><i class="fa fa-align-justify"></i></button>
            <button type="button" data-toggle="collapse" data-target="#search" class="btn btn-outline-secondary navbar-toggler">
              <span class="sr-only">Toggle search</span>
              <i class="fa fa-search"></i>
            </button>
            <a href="basket.html" class="btn btn-outline-secondary navbar-toggler"><i class="fa fa-shopping-cart"></i></a>
          </div>
          <div id="navigation" class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item"><a href="../pages" class="nav-link">Home</a></li>
              <?php if ($_SESSION["user_session"]["role"]=="Admin"): ?>
                <li class="nav-item"><a class="nav-link" href="accounts.php?role=Admin">Admins</a></li>
                <li class="nav-item"><a class="nav-link" href="accounts.php?role=Cardiologist">Cardiologists</a></li>
                <li class="nav-item"><a class="nav-link" href="accounts.php?role=Patient">Patients</a></li>
              <?php endif; ?>
              <?php if ($_SESSION["user_session"]["role"]=="Cardiologist"): ?>
                <li class="nav-item"><a href="medicines.php" class="nav-link">Medicines</a></li>
                <li class="nav-item"><a href="appointment-calendar.php" class="nav-link">Appointment</a></li>
                <li class="nav-item"><a href="predictions.php" class="nav-link">HD Prediction</a></li>
              <?php endif; ?>

            </ul>
            <!-- <div class="navbar-buttons d-flex justify-content-end"> -->
              <!-- /.nav-collapse-->
              <!-- <div id="search-not-mobile" class="navbar-collapse collapse"></div><a data-toggle="collapse" href="#search" class="btn navbar-btn btn-primary d-none d-lg-inline-block"><span class="sr-only">Toggle search</span><i class="fa fa-search"></i></a> -->
              <!-- <div id="basket-overview" class="navbar-collapse collapse d-none d-lg-block"><a href="" class="btn btn-primary navbar-btn"><i class="fa fa-shopping-cart"></i><span><?=$cartTotal;?> items in cart</span></a></div> -->
            <!-- </div> -->
          </div>
        </div>
      </nav>
      <!-- <div id="search" class="collapse">
        <div class="container">
          <form role="search" class="ml-auto" action="search-item.php">
            <div class="input-group">
              <input type="text" placeholder="Search" name="keyWord" class="form-control">
              <div class="input-group-append">
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </form>
        </div>
      </div> -->
    </header>
    <div id="all">
      <div id="content">
        <div class="container">
          <div class="row">
              <div class="col-lg-12">
