<?php
include "../templates/api-header.php";
include "interface.php";

$json = array();
$success = false;
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $user = user()->get("username='$username'");

  //Prediction
  $knnage = $_POST["age"];
  $knnsex = $_POST["sex"];
  $knncp = $_POST["cp"];
  $knntrestbps = $_POST["trestbps"];
  $knnchol = $_POST["chol"];
  $knnfbs = $_POST["fbs"];
  $knnrestecg = $_POST["restecg"];
  $knnthalach = $_POST["thalach"];
  $knnexang = $_POST["exang"];
  $knnoldpeak = $_POST["oldpeak"];
  $knnslope = $_POST["slope"];
  $knnca = $_POST["ca"];
  $knnthal = $_POST["thal"];

  $knn_list = knn()->list();

  $count = 0;
  $k = 0;
  $totalDistance = 0;
   foreach ($knn_list as $row){
     $count += 1;
     $age = pow($knnage-$row->age,2);
     $sex = pow($knnsex-$row->sex,2);
     $cp = pow($knncp-$row->cp,2);
     $trestbps = pow($knntrestbps-$row->trestbps,2);
     $chol = pow($knnchol-$row->chol,2);
     $fbs = pow($knnfbs-$row->fbs,2);
     $restecg = pow($knnrestecg-$row->restecg,2);
     $thalach = pow($knnthalach-$row->thalach,2);
     $exang = pow($knnexang-$row->exang,2);
     $oldpeak = pow($knnoldpeak-$row->oldpeak,2);
     $slope = pow($knnslope-$row->slope,2);
     $ca = pow($knnca-$row->ca,2);
     $thal = pow($knnthal-$row->thal,2);
     $total = $age + $sex + $cp + $trestbps + $chol + $fbs + $restecg + $thalach + $exang + $oldpeak + $slope + $ca + $thal;
     $distance  = decimal_2(sqrt($total));
     if ($distance>=50) {
       $result = 0;
     }
     else{
       $result = 1;
     }

     // First Five
     // if ($count<=5) {
     //   if ($result==1) {
     //     $k += 20;
     //   }
     // }

    $totalDistance += $distance;


   }

  // End prediction

  $model = knn();
  $model->obj["userId"] = $user->Id;
  $model->obj["age"] = $_POST["age"];
  $model->obj["sex"] = $_POST["sex"];
  $model->obj["cp"] = $_POST["cp"];
  $model->obj["trestbps"] = $_POST["trestbps"];
  $model->obj["chol"] = $_POST["chol"];
  $model->obj["fbs"] = $_POST["fbs"];
  $model->obj["restecg"] = $_POST["restecg"];
  $model->obj["thalach"] = $_POST["thalach"];
  $model->obj["exang"] = $_POST["exang"];
  $model->obj["oldpeak"] = $_POST["oldpeak"];
  $model->obj["slope"] = $_POST["slope"];
  $model->obj["ca"] = $_POST["ca"];
  $model->obj["thal"] = $_POST["thal"];
  $model->obj["distance"] = $totalDistance;
  $model->obj["result"] = $result;
  $model->obj["dateAdded"] = "NOW()";
  $model->create();

  $success = true;
}

$json["success"] = $success;
$json["distance"] = decimal_2($totalDistance/$count);

header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
