<?php
include "../templates/api-header.php";
include "interface.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $user = user()->get("username='$username'");
  $success = true;
  $cardiologist_list = array();
  foreach (user()->list("role='Cardiologist'") as $row) {
    $cardiologist = user_interface($row);
    array_push($cardiologist_list, $cardiologist);
  }
}

$json["username"] = $_POST["username"];
$json["cardiologist_list"] = $cardiologist_list;
$json["success"] = $success;

header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
