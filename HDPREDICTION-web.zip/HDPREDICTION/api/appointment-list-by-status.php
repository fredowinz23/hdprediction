<?php
include "../templates/api-header.php";
include "interface.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $status = $_POST["status"];
  $user = user()->get("username='$username'");
  $success = true;
  $appointment_list = array();
  foreach (appointment()->list("patientId=$user->Id and status='$status'") as $row) {
    $appointment = appointment_interface($row);
    array_push($appointment_list, $appointment);
  }
}

$json["username"] = $_POST["username"];
$json["appointment_list"] = $appointment_list;
$json["success"] = $success;

header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
