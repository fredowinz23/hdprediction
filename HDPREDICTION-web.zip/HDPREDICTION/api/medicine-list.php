<?php
include "../templates/api-header.php";
include "interface.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $user = user()->get("username='$username'");
  $success = true;
  $medicine_list = array();
  foreach (medicine()->list("Id>0 order by name") as $row) {
    $medicine = medicine_interface($row);
    array_push($medicine_list, $medicine);
  }
}

$json["username"] = $_POST["username"];
$json["medicine_list"] = $medicine_list;
$json["success"] = $success;

header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
