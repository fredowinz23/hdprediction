<?php
include "../templates/api-header.php";
include "interface.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["medicineId"])) {
  $medicineId = $_POST["medicineId"];
  $success = true;
  $medicine = medicine()->get("Id=$medicineId");
  $json["medicine"] = medicine_interface($medicine);
}

$json["medicineId"] = $_POST["medicineId"];
$json["success"] = $success;

header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
