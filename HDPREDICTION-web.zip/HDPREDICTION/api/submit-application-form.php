<?php
include "../templates/api-header.php";
include "interface.php";

$json = array();
$success = false;
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $user = user()->get("username='$username'");

  $model = appointment();
  $model->obj["patientId"] = $user->Id;
  $model->obj["cardiologistId"] = $_POST["cardiologistId"];
  $model->obj["appointmentDate"] = $_POST["appointmentDate"];
  $model->obj["note"] = $_POST["note"];
  $model->obj["dateAdded"] = "NOW()";
  $model->create();

  $success = true;
}

$json["username"] = $_POST["username"];
$json["cardiologistId"] = $_POST["cardiologistId"];
$json["appointmentDate"] = $_POST["appointmentDate"];
$json["note"] = $_POST["note"];
$json["success"] = $success;

header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
