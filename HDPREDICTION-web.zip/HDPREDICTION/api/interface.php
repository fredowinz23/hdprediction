<?php

function user_interface($object){
  $response = array();
  $response["id"] = $object->Id;
  $response["username"] = $object->username;
  $response["email"] = $object->email;
  $response["phone"] = $object->phone;
  $response["firstName"] = $object->firstName;
  $response["lastName"] = $object->lastName;
  $response["status"] = $object->status;
  return $response;
}

function medicine_interface($object){
  $BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
  $user = user()->get("Id=$object->addedById");
  $response = array();
  $response["id"] = $object->Id;
  $response["image"] = $BASE_URL . "/hdprediction/media/" . $object->image;
  $response["name"] = $object->name;
  $response["uses"] = $object->uses;
  $response["sideEffect"] = $object->sideEffect;
  $response["precaution"] = $object->precaution;
  $response["dateAdded"] = $object->dateAdded;
  $response["addedBy"] = user_interface($user);
  return $response;
}

function appointment_interface($object){
  $BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
  $patient = user()->get("Id=$object->patientId");
  $cardiologist = user()->get("Id=$object->cardiologistId");
  $response = array();
  $response["id"] = $object->Id;
  $response["patient"] = user_interface($patient);
  $response["cardiologist"] = user_interface($cardiologist);
  $response["appointmentDate"] = $object->appointmentDate;
  $response["dateAdded"] = $object->dateAdded;
  $response["status"] = $object->status;
  $response["note"] = $object->note;
  return $response;
}

?>
