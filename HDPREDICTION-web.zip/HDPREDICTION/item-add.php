<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$storeId = $_GET["storeId"];
$catId = $_GET["catId"];
$category = category()->get("Id=$catId");
?>

<h2 class="mt-3">Add <b><?=$category->name;?></b> Item</h2>
<form action="process.php?action=item-add" enctype="multipart/form-data" method="post">
<div class="card">
  <div class="card-header">
    <b>Form</b>
  </div>
  <div class="card-body">

      <div class="col-lg-6">
        <b>Name</b>
        <input type="text"class="form-control" name="name" required>
        <input type="hidden"class="form-control" name="categoryId" value="<?=$catId;?>">
        <input type="hidden"class="form-control" name="storeId" value="<?=$storeId;?>">
      </div>

      <div class="col-lg-6">
        <b>Description</b>
        <textarea name="description" rows="8" cols="80" class="form-control" required></textarea>
      </div>

      <div class="col-lg-6">
        <b>Price</b>
        <input type="number" class="form-control" name="price" required>
      </div>

      <div class="col-lg-6">
        <b>quantity</b>
        <input type="number"class="form-control" name="quantity" required>
      </div>

    <div class="col-lg-6">
      <b>Upload Image</b>
      <input type="file" class="form-control" name="image" required>
    </div>

    <div class="col-lg-6 mt-2">
      <button type="submit" class="btn btn-primary">Add this item</button>
    </div>

  </div>
</div>

</form>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
