﻿# Host: localhost  (Version 5.5.5-10.1.34-MariaDB)
# Date: 2023-05-12 12:06:58
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "appointment"
#

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE `appointment` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `patientId` int(11) DEFAULT NULL,
  `cardiologistId` int(11) DEFAULT NULL,
  `appointmentDate` date DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  `status` varchar(255) DEFAULT 'Pending',
  `note` text,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "appointment"
#


#
# Structure for table "knn"
#

DROP TABLE IF EXISTS `knn`;
CREATE TABLE `knn` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` int(11) DEFAULT NULL,
  `cp` int(11) DEFAULT NULL,
  `trestbps` int(11) DEFAULT NULL,
  `chol` int(11) DEFAULT NULL,
  `fbs` int(11) DEFAULT NULL,
  `restecg` int(11) DEFAULT NULL,
  `thalach` int(11) DEFAULT NULL,
  `exang` int(11) DEFAULT NULL,
  `oldpeak` int(11) DEFAULT NULL,
  `slope` int(11) DEFAULT NULL,
  `ca` int(11) DEFAULT NULL,
  `thal` int(11) DEFAULT NULL,
  `result` int(11) DEFAULT NULL,
  `distance` int(11) DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "knn"
#

INSERT INTO `knn` VALUES (1,0,63,1,3,145,233,1,0,150,0,2,0,0,1,NULL,NULL,'2023-05-11'),(2,0,37,1,2,130,250,0,1,187,0,3,0,0,2,NULL,NULL,'2023-05-11'),(3,0,41,0,1,130,204,0,0,172,0,1,2,0,2,NULL,NULL,'2023-05-11'),(4,0,56,1,1,120,236,0,1,178,0,0,2,0,2,NULL,NULL,'2023-05-11'),(5,0,57,0,0,120,354,0,1,163,1,0,2,0,2,NULL,NULL,NULL),(6,0,57,1,0,140,192,0,1,148,0,0,1,0,1,NULL,NULL,NULL),(7,0,56,0,1,140,294,0,0,153,0,1,1,0,2,NULL,NULL,NULL),(8,0,44,1,1,120,263,0,1,173,0,0,2,0,3,NULL,NULL,NULL),(9,0,52,1,2,172,199,1,1,162,0,0,2,0,3,NULL,NULL,NULL),(10,0,57,1,2,150,168,0,1,174,0,1,2,0,2,NULL,NULL,NULL);

#
# Structure for table "medicine"
#

DROP TABLE IF EXISTS `medicine`;
CREATE TABLE `medicine` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `uses` text,
  `sideEffect` text,
  `precaution` text,
  `addedById` int(11) DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# Data for table "medicine"
#

INSERT INTO `medicine` VALUES (1,'1672830016.jpg','sass','kjkjh','kjhkj','kjhjkh',27,'2023-01-04');

#
# Structure for table "user"
#

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `Id` tinyint(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Inactive',
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;

#
# Data for table "user"
#

INSERT INTO `user` VALUES (16,'admin','1234','Admin','Admin','Active','Admin','2022-10-18','329848324328432984','ssdsfds@sdsd.com'),(26,'qq','12','djdj','djdjd','Active','Patient','2023-01-04','885','sksks@dde.com'),(27,'aa','1234','aa','aa','Active','Cardiologist','2023-01-04','09809','aa');
