package com.capstone.hdprediction.models

import com.google.gson.annotations.SerializedName

data class AppointmentListRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("status")
    var status: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("appointment_list")
    var appointment_list: List<Appointment>? = null
)