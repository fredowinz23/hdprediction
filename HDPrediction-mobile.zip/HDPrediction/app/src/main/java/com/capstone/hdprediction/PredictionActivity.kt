package com.capstone.hdprediction

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import com.capstone.hdprediction.databinding.ActivityPredictionBinding

class PredictionActivity : AppCompatActivity() {
    lateinit var binding: ActivityPredictionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPredictionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.llStartPrediction.setOnClickListener {
            startActivity(Intent(this, PredictionFormActivity::class.java))
            finish()
        }
    }
}