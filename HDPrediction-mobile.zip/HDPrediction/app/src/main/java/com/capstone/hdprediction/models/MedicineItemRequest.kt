package com.capstone.hdprediction.models

import com.google.gson.annotations.SerializedName

data class MedicineItemRequest(
    @SerializedName("medicineId")
    var medicineId: Int,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("medicine")
    var medicine: Medicine? = null
)