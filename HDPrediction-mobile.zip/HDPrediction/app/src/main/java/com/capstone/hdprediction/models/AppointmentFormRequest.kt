package com.capstone.hdprediction.models

import com.google.gson.annotations.SerializedName

data class AppointmentFormRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("cardiologistId")
    var cardiologistId: Int,

    @SerializedName("appointmentDate")
    var appointmentDate: String,

    @SerializedName("note")
    var note: String,

    @SerializedName("success")
    var success: Boolean = false,
)