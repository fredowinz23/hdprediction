package com.capstone.hdprediction.models

import com.google.gson.annotations.SerializedName

data class ProfileRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("user")
    var user: User? = null
)