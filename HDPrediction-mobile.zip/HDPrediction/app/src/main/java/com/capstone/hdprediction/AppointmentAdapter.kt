package com.capstone.hdprediction

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.capstone.hdprediction.models.Appointment

class AppointmentAdapter(private var context: Context?, private val mList: List<Appointment>) : RecyclerView.Adapter<AppointmentAdapter.ViewHolder>() {

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_appointment_list, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = mList[position]

        holder.appointmentDate.text = item.appointmentDate
        holder.name.text = "${item.cardiologist!!.firstName} ${item.cardiologist!!.lastName}"
        holder.status.text = item.status
        holder.note.text = item.note
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val note: TextView = itemView.findViewById(R.id.tvNote)
        val status: TextView = itemView.findViewById(R.id.tvStatus)
        val name: TextView = itemView.findViewById(R.id.tvName)
        val appointmentDate: TextView = itemView.findViewById(R.id.tvAppointmentDate)
        val appointmentItem: LinearLayout = itemView.findViewById(R.id.llAppointmentItem)
    }
}
