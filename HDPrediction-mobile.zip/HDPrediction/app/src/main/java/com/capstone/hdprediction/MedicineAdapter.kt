package com.capstone.hdprediction

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.capstone.hdprediction.R
import com.capstone.hdprediction.auth.LoginActivity
import com.capstone.hdprediction.debug.LeaveRequest
import com.capstone.hdprediction.models.Medicine

class MedicineAdapter(private var context: Context?, private val mList: List<Medicine>) : RecyclerView.Adapter<MedicineAdapter.ViewHolder>() {

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_medicine_list, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = mList[position]

        holder.name.text = item.name
        holder.medicineItem.setOnClickListener {
            val intent = Intent(context, MedicineDetailActivity::class.java)
            intent.putExtra("medicineId", item.id)
            (context as MedicineListActivity).startActivity(intent)
        }
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val name: TextView = itemView.findViewById(R.id.tvName)
        val medicineItem: LinearLayout = itemView.findViewById(R.id.llMedicineItem)
    }
}
