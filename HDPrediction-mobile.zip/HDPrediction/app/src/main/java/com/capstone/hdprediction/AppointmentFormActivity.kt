package com.capstone.hdprediction

import android.app.DatePickerDialog
import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.capstone.hdprediction.api.ApiInterface
import com.capstone.hdprediction.api.RetrofitClient
import com.capstone.hdprediction.api.UserSession
import com.capstone.hdprediction.databinding.ActivityAppointmentFormBinding
import com.capstone.hdprediction.debug.LeaveRequest
import com.capstone.hdprediction.models.AppointmentFormRequest
import com.capstone.hdprediction.models.CardiologistListRequest
import com.capstone.hdprediction.ui.main.CardiologistAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class AppointmentFormActivity : AppCompatActivity() {

    lateinit var binding: ActivityAppointmentFormBinding
    var cardiologistId = 0
    var appointmentDate = ""
    lateinit var builder: Dialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAppointmentFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.ivBack.setOnClickListener {
            finish()
        }

        binding.llSelectCardiologist.setOnClickListener {
            openDialog()
        }

        val myCalendar = Calendar.getInstance()
        val startDateListener = datePickerListener(binding.tvStartDate)

        binding.llAppointmentDate.setOnClickListener {
            DatePickerDialog(this, startDateListener, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show()
        }

        binding.btnSubmit.setOnClickListener {
            if (binding.etNote.text.isEmpty() || appointmentDate=="" || cardiologistId==0){
                Toast.makeText(
                    this,
                    "Fields Must not be empty",
                    Toast.LENGTH_LONG
                ).show()
            }
            else{
                submitRequest(cardiologistId, appointmentDate, binding.etNote.text.toString())
            }
        }
    }

    private fun datePickerListener(dateInput: TextView): DatePickerDialog.OnDateSetListener {
        val myCalendar = Calendar.getInstance()
        return DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
            // TODO Auto-generated method stub
            myCalendar.set(Calendar.YEAR, year)
            myCalendar.set(Calendar.MONTH, monthOfYear)
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            dateInput.text = year.toString() +"-"+ (monthOfYear+1).toString() +"-"+ dayOfMonth.toString()
            appointmentDate = dateInput.text.toString()
        }
    }

    private fun submitRequest(cardiologistId: Int, appointmentDate: String, note: String) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        binding.btnSubmit.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        val userSession = UserSession(this)
        val applicationForm = AppointmentFormRequest(userSession.username!!, cardiologistId,
                                                appointmentDate, note)

        val call = retrofitAPI.submitApplicationForm(applicationForm)

        call.enqueue(object : Callback<AppointmentFormRequest?> {
            override fun onResponse(call: Call<AppointmentFormRequest?>, response: Response<AppointmentFormRequest?>) {
                val responseFromAPI: AppointmentFormRequest? = response.body()
                finish()
            }

            override fun onFailure(call: Call<AppointmentFormRequest?>, t: Throwable) {

                Toast.makeText(
                    this@AppointmentFormActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()

                binding.progressBar.visibility = View.GONE
                binding.btnSubmit.visibility = View.VISIBLE
                Log.e("Login Error", t.message.toString())
            }
        })
    }

    private fun openDialog(){
        val view = layoutInflater.inflate(R.layout.dialog_cardiologist_options, null)
        val cardiologistList = view.findViewById(R.id.rvCardiologistList) as RecyclerView
        builder = Dialog(this)

        builder.setContentView(view)
        builder.show()
        builder.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(this)
        val cardioList = CardiologistListRequest(userSession.username!!)
        val call = retrofitAPI.getCardiologistList(cardioList)

        call.enqueue(object : retrofit2.Callback<CardiologistListRequest?> {
            override fun onResponse(call: Call<CardiologistListRequest?>, response: Response<CardiologistListRequest?>) {

                val responseFromAPI: CardiologistListRequest? = response.body()

                val groupLinear = LinearLayoutManager(this@AppointmentFormActivity)
                cardiologistList.layoutManager = groupLinear
                val data = responseFromAPI?.cardiologist_list!!

                val adapter = CardiologistAdapter(this@AppointmentFormActivity, data)
                cardiologistList.adapter = adapter
            }

            override fun onFailure(call: Call<CardiologistListRequest?>, t: Throwable) {

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    this@AppointmentFormActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }

        })
    }
}