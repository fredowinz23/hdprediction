package com.capstone.hdprediction.models

import com.google.gson.annotations.SerializedName

data class CardiologistListRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("cardiologist_list")
    var cardiologist_list: List<User>? = null
)