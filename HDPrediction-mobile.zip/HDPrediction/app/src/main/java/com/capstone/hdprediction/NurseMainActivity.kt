package com.capstone.hdprediction

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import com.capstone.hdprediction.databinding.ActivityNurseMainBinding

class NurseMainActivity : AppCompatActivity() {
    lateinit var binding: ActivityNurseMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityNurseMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

//        binding.ivMainImage.setOnClickListener {
//            startActivity(Intent(this, MainActivity::class.java))
//        }

        binding.cvMedicines.setOnClickListener {
            startActivity(Intent(this, MedicineListActivity::class.java))
        }

        binding.cvPredictions.setOnClickListener {
            startActivity(Intent(this, PredictionActivity::class.java))
        }
//
        binding.cvProfile.setOnClickListener {
            startActivity(Intent(this, MyProfileActivity::class.java))
        }

        binding.cvAppointments.setOnClickListener {
            startActivity(Intent(this, AppointmentActivity::class.java))
        }
    }
}