package com.capstone.hdprediction

import android.R
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.capstone.hdprediction.api.ApiInterface
import com.capstone.hdprediction.api.RetrofitClient
import com.capstone.hdprediction.api.UserSession
import com.capstone.hdprediction.databinding.ActivityPredictionFormBinding
import com.capstone.hdprediction.models.PredictionFormRequest
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class PredictionFormActivity : AppCompatActivity() {
    lateinit var binding: ActivityPredictionFormBinding
    var sexSelected = "1"
    var cpSelected = "1"
    var fbsSelected = "0"
    var restecgSelected = "0"
    var exangSelected = "0"
    var oldpeakSelected = ""
    var slopeSelected = ""
    var caSelected = "0"
    var thalSelected = "3"

    val genderArray = arrayOf("1", "0")
    val cpArray = arrayOf("1", "2", "3", "4")
    val fbsArray = arrayOf("0", "1")
    val reArray = arrayOf("0", "1", "2")
    val eiaArray = arrayOf("0", "1")
    val caArray = arrayOf("0", "1", "2", "3")
    val thalArray = arrayOf("3", "6", "7")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPredictionFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)


        binding.ivBack.setOnClickListener {
            finish()
        }

        binding.spCA.adapter = ArrayAdapter(this,
            R.layout.simple_spinner_dropdown_item,
            caArray
        )

        binding.spChest.adapter = ArrayAdapter(this,
            R.layout.simple_spinner_dropdown_item,
            cpArray
        )

        binding.spEia.adapter = ArrayAdapter(this,
            R.layout.simple_spinner_dropdown_item,
            eiaArray
        )

        binding.spFsb.adapter = ArrayAdapter(this,
            R.layout.simple_spinner_dropdown_item,
            fbsArray
        )

        binding.spGender.adapter = ArrayAdapter(this,
            R.layout.simple_spinner_dropdown_item,
            genderArray
        )

        binding.spRe.adapter = ArrayAdapter(this,
            R.layout.simple_spinner_dropdown_item,
            reArray
        )

        binding.spThal.adapter = ArrayAdapter(this,
            R.layout.simple_spinner_dropdown_item,
            thalArray
        )

        binding.spGender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                sexSelected = genderArray[position]
            }
        }

        binding.spChest.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                cpSelected = cpArray[position]
            }
        }

        binding.spFsb.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                fbsSelected = fbsArray[position]
            }
        }

        binding.spRe.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                restecgSelected = reArray[position]
            }
        }

        binding.spEia.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                exangSelected = eiaArray[position]
            }
        }

        binding.spCA.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                caSelected = caArray[position]
            }
        }

        binding.spThal.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                thalSelected = thalArray[position]
            }
        }

        binding.btnSubmit.setOnClickListener {
            if (binding.etAge.text.isEmpty() ||
                sexSelected == "" ||
                cpSelected == "" ||
                binding.etTrestbps.text.isEmpty() ||
                binding.etCholesterol.text.isEmpty() ||
                fbsSelected == "" ||
                restecgSelected == "" ||
                binding.etHr.text.isEmpty() ||
                exangSelected == "" ||
                binding.etOldPeak.text.isEmpty() ||
                binding.etSlope.text.isEmpty() ||
                caSelected == "" ||
                thalSelected == ""){
                Toast.makeText(
                    this,
                    "Fields Must not be empty",
                    Toast.LENGTH_LONG
                ).show()
            }
            else{
                submitRequest(binding.etAge.text.toString().toInt(),
                        sexSelected.toInt(),
                        cpSelected.toInt(),
                        binding.etTrestbps.text.toString().toInt(),
                        binding.etCholesterol.text.toString().toInt(),
                        fbsSelected.toInt(),
                        restecgSelected.toInt(),
                        binding.etHr.text.toString().toInt(),
                        exangSelected.toInt(),
                        binding.etOldPeak.text.toString().toInt(),
                        binding.etSlope.text.toString().toInt(),
                        caSelected.toInt(),
                        thalSelected.toInt())
            }
        }
    }

    private fun submitRequest(
        age: Int,
        sex: Int,
        cp: Int,
        trestbps: Int,
        cholesterol: Int,
        fbs: Int,
        restecg: Int,
        hr: Int,
        exang: Int,
        oldpeak: Int,
        slope: Int,
        ca: Int,
        thal: Int
    ) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        binding.btnSubmit.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        val userSession = UserSession(this)
        val predictionForm = PredictionFormRequest(userSession.username!!,
            age, sex, cp, trestbps, cholesterol, fbs, restecg, hr, exang,
            oldpeak, slope, ca, thal
        )

        val call = retrofitAPI.submitPredictionForm(predictionForm)

        call.enqueue(object : Callback<PredictionFormRequest?> {
            override fun onResponse(call: Call<PredictionFormRequest?>, response: Response<PredictionFormRequest?>) {
                val responseFromAPI: PredictionFormRequest? = response.body()

                val intent = Intent(this@PredictionFormActivity, PredictionResultActivity::class.java)
                intent.putExtra("distance", responseFromAPI?.distance)
                startActivity(intent)
                finish()
            }

            override fun onFailure(call: Call<PredictionFormRequest?>, t: Throwable) {

                Toast.makeText(
                    this@PredictionFormActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()

                binding.progressBar.visibility = View.GONE
                binding.btnSubmit.visibility = View.VISIBLE
                Log.e("Login Error", t.message.toString())
            }
        })
    }
}