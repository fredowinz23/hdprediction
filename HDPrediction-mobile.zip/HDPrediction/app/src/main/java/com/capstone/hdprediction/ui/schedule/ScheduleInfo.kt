package com.capstone.hdprediction.ui.schedule

import com.google.gson.annotations.SerializedName
import com.capstone.hdprediction.debug.Schedule

data class ScheduleInfo(
    @SerializedName("username")
    var username: String,

    @SerializedName("date")
    var date: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("status")
    var status: String = "",

    @SerializedName("schedule")
    var schedule: Schedule? = null
)