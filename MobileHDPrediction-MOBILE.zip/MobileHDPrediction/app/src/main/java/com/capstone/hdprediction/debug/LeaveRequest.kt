package com.capstone.hdprediction.debug

import com.google.gson.annotations.SerializedName

data class LeaveRequest(
    @SerializedName("id")
    var id: Int = 0,

    @SerializedName("username")
    var username: String = "",

    @SerializedName("startDate")
    var startDate: String = "",

    @SerializedName("endDate")
    var endDate: String = "",

    @SerializedName("leaveType")
    var leaveType: String = "",

    @SerializedName("leaveTypeId")
    var leaveTypeId: Int = 0,

    @SerializedName("reason")
    var reason: String = "",

    @SerializedName("success")
    var success: String = "",

)