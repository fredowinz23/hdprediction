package com.capstone.hdprediction.models

import com.google.gson.annotations.SerializedName

data class Appointment(
    @SerializedName("id")
    var id: Int = 0,

    @SerializedName("patient")
    var patient: User? = null,

    @SerializedName("cardiologist")
    var cardiologist: User? = null,

    @SerializedName("appointmentDate")
    var appointmentDate: String = "",

    @SerializedName("dateAdded")
    var dateAdded: String = "",

    @SerializedName("status")
    var status: String = "",

    @SerializedName("note")
    var note: String = "",
)