package com.capstone.hdprediction

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import com.capstone.hdprediction.databinding.ActivityPredictionResultBinding

class PredictionResultActivity : AppCompatActivity() {
    lateinit var binding: ActivityPredictionResultBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPredictionResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)


        val distance = intent.extras?.getFloat("distance", 0f)!!

        val rnds = (9..99).random()

        binding.tvPercentage.text = "$distance%"
        if (rnds>50){
            binding.tvDescription.text = "High Possibility of Heart Disease"
        }
        else{
            binding.tvDescription.text = "Low Possibility of Heart Disease"
        }

        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}