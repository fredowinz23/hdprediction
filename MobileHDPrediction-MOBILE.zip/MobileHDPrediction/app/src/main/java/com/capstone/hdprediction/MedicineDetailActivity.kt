package com.capstone.hdprediction

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.capstone.hdprediction.api.ApiInterface
import com.capstone.hdprediction.api.RetrofitClient
import com.capstone.hdprediction.databinding.ActivityMedicineDetailBinding
import com.capstone.hdprediction.models.MedicineItemRequest
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MedicineDetailActivity : AppCompatActivity() {
    lateinit var binding: ActivityMedicineDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMedicineDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.ivBack.setOnClickListener {
            finish()
        }

        val medicineId = intent.extras?.getInt("medicineId", 0)

        getMedicineById(medicineId)
    }

    private fun getMedicineById(medicineId: Int?) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val medicineItem = MedicineItemRequest(medicineId!!)
        val call = retrofitAPI.getMedicineItem(medicineItem)

        call.enqueue(object : Callback<MedicineItemRequest?> {
            override fun onResponse(call: Call<MedicineItemRequest?>, response: Response<MedicineItemRequest?>) {

                // and passing it to our modal class.
                val responseFromAPI: MedicineItemRequest? = response.body()

                binding.tvName.text = responseFromAPI?.medicine!!.name
                binding.tvUses.text = responseFromAPI.medicine!!.uses
                binding.tvSideEffect.text = responseFromAPI.medicine!!.sideEffect
                binding.tvPrecaution.text = responseFromAPI.medicine!!.precaution
                Picasso.with(this@MedicineDetailActivity).load(responseFromAPI.medicine!!.image).fit().centerCrop()
                    .placeholder(R.drawable.logo)
                    .error(R.drawable.logo)
                    .into(binding.ivImage)
            }

            override fun onFailure(call: Call<MedicineItemRequest?>, t: Throwable) {
                // setting text to our text view when

                Toast.makeText(
                    this@MedicineDetailActivity,
                    t.message.toString(),
                    Toast.LENGTH_LONG
                ).show()

                Log.e("Login Error", t.message.toString())
            }
        })
    }
}