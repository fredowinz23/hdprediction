package com.capstone.hdprediction.api

import com.capstone.hdprediction.debug.LeaveRequest
import com.capstone.hdprediction.debug.ProfileInfo
import com.capstone.hdprediction.models.*
import com.capstone.hdprediction.ui.main.LeaveInfo
import com.capstone.hdprediction.ui.main.LeaveTypeInfo
import com.capstone.hdprediction.ui.main.MyScheduleListInfo
import com.capstone.hdprediction.ui.schedule.ScheduleInfo
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Headers


interface ApiInterface {
    @Headers("Content-Type: application/json")
    @POST("api/login.php")
    fun loginUser(@Body loginRequest: LoginRequest): Call<LoginRequest>

    @Headers("Content-Type: application/json")
    @POST("api/signup.php")
    fun signupUser(@Body signUpRequest: SignUpRequest): Call<SignUpRequest>

    @Headers("Content-Type: application/json")
    @POST("api/profile.php")
    fun getProfile(@Body profileRequest: ProfileRequest): Call<ProfileRequest>

    @Headers("Content-Type: application/json")
    @POST("api/medicine-list.php")
    fun getMedicineList(@Body medicineListRequest: MedicineListRequest): Call<MedicineListRequest>

    @Headers("Content-Type: application/json")
    @POST("api/medicine-item.php")
    fun getMedicineItem(@Body medicineItemRequest: MedicineItemRequest): Call<MedicineItemRequest>

    @Headers("Content-Type: application/json")
    @POST("api/appointment-list-by-status.php")
    fun getAppointmentList(@Body appointmentListRequest: AppointmentListRequest): Call<AppointmentListRequest>

    @Headers("Content-Type: application/json")
    @POST("api/cardiologist-list.php")
    fun getCardiologistList(@Body cardiologistListRequest: CardiologistListRequest): Call<CardiologistListRequest>

    @Headers("Content-Type: application/json")
    @POST("api/submit-application-form.php")
    fun submitApplicationForm(@Body appointmentFormRequest: AppointmentFormRequest): Call<AppointmentFormRequest>

    @Headers("Content-Type: application/json")
    @POST("api/submit-prediction-form.php")
    fun submitPredictionForm(@Body predictionFormRequest: PredictionFormRequest): Call<PredictionFormRequest>

    @Headers("Content-Type: application/json")
    @POST("api/change-password.php")
    fun changePassword(@Body loginRequest: LoginRequest): Call<LoginRequest>

    @Headers("Content-Type: application/json")
    @POST("api/schedule-by-date.php")
    fun getScheduleInfo(@Body scheduleInfo: ScheduleInfo): Call<ScheduleInfo>

    @Headers("Content-Type: application/json")
    @POST("api/nurse-schedule-list.php")
    fun getMyScheduleListInfo(@Body myScheduleListInfo: MyScheduleListInfo): Call<MyScheduleListInfo>

    @Headers("Content-Type: application/json")
    @POST("api/my-leave-request.php")
    fun getMyLeaveRequest(@Body leaveInfo: LeaveInfo): Call<LeaveInfo>

    @Headers("Content-Type: application/json")
    @POST("api/leave-type-list.php")
    fun getLeaveTypeList(@Body leaveTypeInfo: LeaveTypeInfo): Call<LeaveTypeInfo>

    @Headers("Content-Type: application/json")
    @POST("api/submit-leave-request.php")
    fun submitLeaveRequest(@Body leaveRequest: LeaveRequest): Call<LeaveRequest>


}