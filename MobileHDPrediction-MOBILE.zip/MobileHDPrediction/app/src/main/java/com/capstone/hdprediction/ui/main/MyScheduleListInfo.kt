package com.capstone.hdprediction.ui.main

import com.capstone.hdprediction.debug.Schedule
import com.google.gson.annotations.SerializedName

data class MyScheduleListInfo(
    @SerializedName("username")
    var username: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("schedule_list")
    var schedule_list: List<Schedule>? = null
)