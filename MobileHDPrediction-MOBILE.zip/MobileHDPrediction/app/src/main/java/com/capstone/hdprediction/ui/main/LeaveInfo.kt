package com.capstone.hdprediction.ui.main

import com.capstone.hdprediction.debug.LeaveRequest
import com.google.gson.annotations.SerializedName

data class LeaveInfo(
    @SerializedName("username")
    var username: String,

    @SerializedName("status")
    var status: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("leave_list")
    var leave_list: List<LeaveRequest>? = null
)