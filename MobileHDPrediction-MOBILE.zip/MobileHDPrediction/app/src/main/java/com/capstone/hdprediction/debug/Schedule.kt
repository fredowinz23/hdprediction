package com.capstone.hdprediction.debug

import com.google.gson.annotations.SerializedName

data class Schedule(
    @SerializedName("id")
    var id: Int = 0,

    @SerializedName("nurseId")
    var nurseId: Int = 0,

    @SerializedName("date")
    var date: String = "",

    @SerializedName("shift")
    var shift: String = "",

    @SerializedName("status")
    var status: String = "",

)