package com.capstone.hdprediction.models

import com.google.gson.annotations.SerializedName

data class Medicine(
    @SerializedName("id")
    var id: Int = 0,

    @SerializedName("name")
    var name: String = "",

    @SerializedName("image")
    var image: String = "",

    @SerializedName("uses")
    var uses: String = "",

    @SerializedName("sideEffect")
    var sideEffect: String = "",

    @SerializedName("precaution")
    var precaution: String = "",

    @SerializedName("dateAdded")
    var dateAdded: String = "",

    @SerializedName("addedBy")
    var addedBy: User? = null,

)