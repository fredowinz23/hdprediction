package com.capstone.hdprediction.models

import com.google.gson.annotations.SerializedName

data class Knn(
    @SerializedName("id")
    var id: Int = 0,

    @SerializedName("age")
    var age: Int = 0,

    @SerializedName("sex")
    var sex: Int = 0,

    @SerializedName("cp")
    var cp: Int = 0,

    @SerializedName("trestbsp")
    var trestbsp: Int = 0,

    @SerializedName("chol")
    var chol: Int = 0,

    @SerializedName("fbs")
    var fbs: Int = 0,

    @SerializedName("restecg")
    var restecg: Int = 0,

    @SerializedName("thalach")
    var thalach: Int = 0,

    @SerializedName("exang")
    var exang: Int = 0,

    @SerializedName("oldpeak")
    var oldpeak: Int = 0,

    @SerializedName("slope")
    var slope: Int = 0,

    @SerializedName("ca")
    var ca: Int = 0,

    @SerializedName("thal")
    var thal: Int = 0,

    @SerializedName("result")
    var result: Int = 0,

    @SerializedName("distance")
    var distance: Int = 0,

    @SerializedName("dateAdded")
    var dateAdded: String = ""
)