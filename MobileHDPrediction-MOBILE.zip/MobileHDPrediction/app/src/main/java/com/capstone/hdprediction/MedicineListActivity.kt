package com.capstone.hdprediction

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import com.capstone.hdprediction.api.ApiInterface
import com.capstone.hdprediction.api.RetrofitClient
import com.capstone.hdprediction.api.UserSession
import com.capstone.hdprediction.databinding.ActivityMedicineListBinding
import com.capstone.hdprediction.models.MedicineListRequest
import retrofit2.Call
import retrofit2.Response

class MedicineListActivity : AppCompatActivity() {
    lateinit var binding: ActivityMedicineListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMedicineListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.ivBack.setOnClickListener {
            finish()
        }

        getMedicineList()
    }

    private fun getMedicineList() {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(this)
        val medicineList = MedicineListRequest(userSession.username!!)
        val call = retrofitAPI.getMedicineList(medicineList)

        call.enqueue(object : retrofit2.Callback<MedicineListRequest?> {
            override fun onResponse(call: Call<MedicineListRequest?>, response: Response<MedicineListRequest?>) {

                val responseFromAPI: MedicineListRequest? = response.body()

                val groupLinear = LinearLayoutManager(this@MedicineListActivity)
                binding.rvMedicineList.layoutManager = groupLinear
                val data = responseFromAPI?.medicine_list!!

                val adapter = MedicineAdapter(this@MedicineListActivity, data)
                binding.rvMedicineList.adapter = adapter
            }

            override fun onFailure(call: Call<MedicineListRequest?>, t: Throwable) {

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    this@MedicineListActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }

        })
    }
}