package com.capstone.hdprediction.models

import com.google.gson.annotations.SerializedName

data class MedicineListRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("medicine_list")
    var medicine_list: List<Medicine>? = null
)