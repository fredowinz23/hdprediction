package com.capstone.hdprediction.debug

import android.R
import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.applandeo.materialcalendarview.EventDay
import com.capstone.hdprediction.api.ApiInterface
import com.capstone.hdprediction.api.RetrofitClient
import com.capstone.hdprediction.api.UserSession
import com.capstone.hdprediction.databinding.ActivityMyScheduleBinding
import com.capstone.hdprediction.ui.main.MyScheduleListInfo
import com.capstone.hdprediction.ui.schedule.ScheduleInfo
import retrofit2.Call
import retrofit2.Response
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*


class MyScheduleActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMyScheduleBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMyScheduleBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.ivBack.setOnClickListener {
            finish()
        }
        val time = Calendar.getInstance().time
        val formatter = SimpleDateFormat("yyyy-MM-dd")
        val current = formatter.format(time)

        binding.cvMySchedule.setOnDateChangeListener { view, year, month, dayOfMonth ->

            val dayString = convertDate(dayOfMonth)
            val monthString = convertDate(month+1)
            val thisDate = "$year-$monthString-$dayString"
            getScheduleByDate(thisDate)
        }

        binding.calendarView.setOnDayClickListener { eventDay ->
            val year = eventDay.calendar.time.year.toString()
            val month = convertDate(eventDay.calendar.time.month+1)
            val day = convertDate( eventDay.calendar.time.day)
            val dateToday = convertMillisToFormat(eventDay.calendar.timeInMillis, "yyyy-MM-dd")
            Log.e("event calendar", "${dateToday}")
            val thisDate = "$year-$month-$day"
            getScheduleByDate(dateToday.toString())
        }

        getScheduleByDate(current)
//        testAddEvents()

        getMyScheduleList()
    }

    private fun getMyScheduleList() {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(this)
        val scheduleInfo = MyScheduleListInfo(userSession.username.toString())
        val call = retrofitAPI.getMyScheduleListInfo(scheduleInfo)

        call.enqueue(object : retrofit2.Callback<MyScheduleListInfo?> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<MyScheduleListInfo?>, response: Response<MyScheduleListInfo?>) {

                val responseFromAPI: MyScheduleListInfo? = response.body()

                val events: MutableList<EventDay> = ArrayList()

                for (item in responseFromAPI?.schedule_list!!){

                    val dateItem = calendarStringToCalendar(item.date)
                    val year = convertMillisToFormat(dateItem.timeInMillis, "yyyy")
                    val month = convertMillisToFormat(dateItem.timeInMillis, "M")
                    val day = convertMillisToFormat(dateItem.timeInMillis, "dd")

                    val calendar = Calendar.getInstance()
                    val getMonth = month!!.toInt()-1
                    calendar.set(Calendar.MONTH, convertDate(getMonth).toInt());
                    calendar.set(Calendar.DAY_OF_MONTH, day!!.toInt());
                    calendar.set(Calendar.YEAR, year!!.toInt());
                    val drawableImage = resources.getIdentifier("ic_marked", "drawable", "com.capstone.hdprediction")
                    events.add(EventDay(calendar, drawableImage))

                    Log.e("event iteration", "$year-$month-$day")

                }

                binding.calendarView.setEvents(events)

            }

            override fun onFailure(call: Call<MyScheduleListInfo?>, t: Throwable) {
                // setting text to our text view when
                // we get error response from API.
                Log.e("Login Error", t.message.toString())
            }

        })
    }

    fun convertMillisToFormat(milliSeconds: Long, dateFormat: String?): String? {
        // Create a DateFormatter object for displaying date in specified format.
        val formatter = SimpleDateFormat(dateFormat)

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = milliSeconds
        return formatter.format(calendar.time)
    }

    fun calendarStringToCalendar(dateString: String): Calendar {
        val cal = Calendar.getInstance()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        cal.time = sdf.parse(dateString)
        return cal
    }

    fun testAddEvents(){
        val events: MutableList<EventDay> = ArrayList()

        val calendar = Calendar.getInstance()
        calendar.set(Calendar.MONTH, Calendar.DECEMBER);
        calendar.set(Calendar.DAY_OF_MONTH, 9);
        calendar.set(Calendar.YEAR, 2022);
        events.add(EventDay(calendar, R.drawable.ic_dialog_info))


        events.add(EventDay(calendar, R.drawable.ic_delete, Color.parseColor("#228B22")))

        binding.calendarView.setEvents(events)
    }

    private fun convertDate(number: Int): String {
        var result = number.toString()
        if (number < 10) {
            val f = DecimalFormat("00")
            result = java.lang.String.valueOf(f.format(number))
        }
        return result
    }

    private fun getScheduleByDate(scheduleDate: String) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(this)
        val scheduleInfo = ScheduleInfo(userSession.username.toString(), scheduleDate)
        val call = retrofitAPI.getScheduleInfo(scheduleInfo)

        call.enqueue(object : retrofit2.Callback<ScheduleInfo?> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<ScheduleInfo?>, response: Response<ScheduleInfo?>) {

                val responseFromAPI: ScheduleInfo? = response.body()

                val status = responseFromAPI?.status

                binding.progressBar.visibility = View.GONE
                binding.cvEvent.visibility = View.VISIBLE

                binding.tvDate.text = scheduleDate
                binding.tvDutyStatus.text = status
                if (status!="OFF"){
                    binding.tvShift.visibility = View.VISIBLE
                    binding.tvShift.text = responseFromAPI?.schedule!!.shift
                }
                else{
                    binding.tvShift.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<ScheduleInfo?>, t: Throwable) {
                // setting text to our text view when
                // we get error response from API.
                Log.e("Login Error", t.message.toString())
            }

        })
    }
}