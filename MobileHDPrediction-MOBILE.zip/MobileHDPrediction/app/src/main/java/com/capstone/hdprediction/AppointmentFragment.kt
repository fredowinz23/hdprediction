package com.capstone.hdprediction

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.capstone.hdprediction.api.ApiInterface
import com.capstone.hdprediction.api.RetrofitClient
import com.capstone.hdprediction.api.UserSession
import com.capstone.hdprediction.databinding.FragmentAppointmentBinding
import com.capstone.hdprediction.models.AppointmentListRequest
import retrofit2.Call
import retrofit2.Response

class AppointmentFragment(private val position: Int) : Fragment() {
    private var _binding: FragmentAppointmentBinding? = null

    private val binding get() = _binding!!

    private var appointmentStatus = "Pending"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentAppointmentBinding.inflate(inflater, container, false)
        val root: View = binding.root

        appointmentStatus = when (position) {
            0 -> "Pending"
            1 -> "Approved"
            2 -> "Denied"
            else -> "Pending"
        }

        getAppointment(appointmentStatus)

        return root
    }

    private fun getAppointment(appointmentStatus: String) {
        val retrofit = RetrofitClient.getInstance(context)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(context)
        val appointmentList = AppointmentListRequest(userSession.username!!, appointmentStatus)
        val call = retrofitAPI.getAppointmentList(appointmentList)

        call.enqueue(object : retrofit2.Callback<AppointmentListRequest?> {
            override fun onResponse(call: Call<AppointmentListRequest?>, response: Response<AppointmentListRequest?>) {

                binding.progressBar.visibility = View.GONE

                val responseFromAPI: AppointmentListRequest? = response.body()

                val groupLinear = LinearLayoutManager(context)
                binding.rvAppointmentList.layoutManager = groupLinear
                val data = responseFromAPI?.appointment_list!!

                val adapter = AppointmentAdapter(context, data)
                binding.rvAppointmentList.adapter = adapter
            }

            override fun onFailure(call: Call<AppointmentListRequest?>, t: Throwable) {

                binding.progressBar.visibility = View.GONE

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    context,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }

        })
    }

    override fun onResume() {
        getAppointment(appointmentStatus)
        super.onResume()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}